## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
library(SegColR)
library(imager)
example_data <- load_segcolr_example_data()

## -----------------------------------------------------------------------------
img <- example_data$images[[2]]
# View the image
plot(img, axes = FALSE, main = "Andaman Hind")

## -----------------------------------------------------------------------------
img_path <- example_data$image_paths[2]
labels <- "a fish."
file_name <- basename(img_path)
file_name <- sub("\\.[^.]*$", "", file_name)
directory <- dirname(img_path)
json_path <- paste0(gsub("images", "json/", directory), "segcolr_output_", file_name, ".json")

if(!file.exists(json_path)){
  ground_results <- grounded_segmentation_cli(img_path,
    labels,
    output_json = "/home/jboyko/SegColR/extdata/json/",
    output_plot = "/home/jboyko/SegColR/extdata/plot/")
  json_path = ground_results$json_path
}

## -----------------------------------------------------------------------------
seg_results <- load_segmentation_results(
  image_path = img_path,
  json_path = json_path,
  mask_format = "image"
)

## -----------------------------------------------------------------------------
plot_seg_results(
  seg_results = seg_results,
  mask_colors = "Set1",
  background = "grayscale",
  show_label = TRUE,
  show_score = TRUE,
  show_bbox = TRUE,
  score_threshold = 0.5,
  label_size = 1.2,
  bbox_thickness = 2,
  mask_alpha = 0.3
)

## -----------------------------------------------------------------------------
color_results <- process_masks_and_extract_colors(
  image = seg_results$image,
  masks = seg_results$mask,
  scores = seg_results$score,
  labels = seg_results$label,
  include_labels = labels,
  exclude_labels = NULL,
  score_threshold = 0.5,
  n_colors = 5
)

## ---- fig.width=8, fig.height=5-----------------------------------------------
plot_color_info(color_results)

## -----------------------------------------------------------------------------
### Example 1 - basic description
img_path <- example_data$image_paths[1]
labels <- c("a flower.", "a bee.")
file_name <- basename(img_path)
file_name <- sub("\\.[^.]*$", "", file_name)
directory <- dirname(img_path)
json_path <- paste0(gsub("images", "json/", directory), "segcolr_output_", file_name, ".json")

if(!file.exists(json_path)){
  ground_results <- grounded_segmentation_cli(img_path,
    labels,
    output_json = "/home/jboyko/SegColR/extdata/json/",
    output_plot = "/home/jboyko/SegColR/extdata/plot/")
  json_path = ground_results$json_path
}

## -----------------------------------------------------------------------------
seg_results <- load_segmentation_results(
  image_path = img_path,
  json_path = json_path,
  mask_format = "image"
)

plot_seg_results(
  seg_results = seg_results,
  mask_colors = "Set1",
  background = "grayscale",
  show_label = TRUE,
  show_score = TRUE,
  show_bbox = TRUE,
  score_threshold = 0.5,
  label_size = 1.2,
  bbox_thickness = 2,
  mask_alpha = 0.3
)

## -----------------------------------------------------------------------------
plot_seg_results(
  seg_results = seg_results,
  mask_colors = "Set1",
  background = "grayscale",
  show_label = TRUE,
  show_score = TRUE,
  show_bbox = TRUE,
  score_threshold = 0,
  label_size = 1.2,
  bbox_thickness = 2,
  mask_alpha = 0.3
)

## ---- fig.width=8, fig.height=5-----------------------------------------------
color_results <- process_masks_and_extract_colors(
  image = seg_results$image,
  masks = seg_results$mask,
  scores = seg_results$score,
  labels = seg_results$label,
  include_labels = labels[1],
  exclude_labels = NULL,
  score_threshold = 0.5,
  n_colors = 5
)

plot_color_info(color_results)

## ---- fig.width=8, fig.height=5-----------------------------------------------
color_results <- process_masks_and_extract_colors(
  image = seg_results$image,
  masks = seg_results$mask,
  scores = seg_results$score,
  labels = seg_results$label,
  include_labels = labels[1],
  exclude_labels = labels[2],
  score_threshold = 0.5,
  n_colors = 5
)

plot_color_info(color_results)

## -----------------------------------------------------------------------------
img_path <- example_data$image_paths[5]
labels <- "a gecko."
file_name <- basename(img_path)
file_name <- sub("\\.[^.]*$", "", file_name)
directory <- dirname(img_path)
json_path <- paste0(gsub("images", "json/", directory), "segcolr_output_", file_name, ".json")

if(!file.exists(json_path)){
  ground_results <- grounded_segmentation_cli(img_path,
    labels,
    output_json = "/home/jboyko/SegColR/extdata/json/",
    output_plot = "/home/jboyko/SegColR/extdata/plot/")
  json_path = ground_results$json_path
}

seg_results <- load_segmentation_results(
  image_path = img_path,
  json_path = json_path,
  mask_format = "image"
)

plot_seg_results(
  seg_results = seg_results,
  mask_colors = "Set1",
  background = "grayscale",
  show_label = TRUE,
  show_score = TRUE,
  show_bbox = TRUE,
  score_threshold = 0.5,
  label_size = 1.2,
  bbox_thickness = 2,
  mask_alpha = 0.3
)


## ---- fig.width=8, fig.height=5-----------------------------------------------
color_results <- process_masks_and_extract_colors(
  image = seg_results$image,
  masks = seg_results$mask,
  scores = seg_results$score,
  labels = seg_results$label,
  include_labels = labels[1],
  exclude_labels = labels[2],
  score_threshold = 0.3,
  n_colors = 5
)

plot_color_info(color_results)

## -----------------------------------------------------------------------------
img_path <- example_data$image_paths[6]
labels <- "a bird."
file_name <- basename(img_path)
file_name <- sub("\\.[^.]*$", "", file_name)
directory <- dirname(img_path)
json_path <- paste0(gsub("images", "json/", directory), "segcolr_output_", file_name, ".json")

if(!file.exists(json_path)){
  ground_results <- grounded_segmentation_cli(img_path,
    labels,
    output_json = "/home/jboyko/SegColR/extdata/json/",
    output_plot = "/home/jboyko/SegColR/extdata/plot/")
  json_path = ground_results$json_path
}

seg_results <- load_segmentation_results(
  image_path = img_path,
  json_path = json_path,
  mask_format = "image"
)

plot_seg_results(
  seg_results = seg_results,
  mask_colors = "Set1",
  background = "grayscale",
  show_label = TRUE,
  show_score = TRUE,
  show_bbox = TRUE,
  score_threshold = 0.99,
  label_size = 1.2,
  bbox_thickness = 2,
  mask_alpha = 0.3
)


## ---- fig.width=8, fig.height=5-----------------------------------------------
color_results <- process_masks_and_extract_colors(
  image = seg_results$image,
  masks = seg_results$mask,
  scores = seg_results$score,
  labels = seg_results$label,
  include_labels = labels[1],
  exclude_labels = labels[2],
  score_threshold = 0.3,
  n_colors = 5
)

plot_color_info(color_results)

## -----------------------------------------------------------------------------
img_path <- example_data$image_paths[7]
labels <- "a frog."
file_name <- basename(img_path)
file_name <- sub("\\.[^.]*$", "", file_name)
directory <- dirname(img_path)
json_path <- paste0(gsub("images", "json/", directory), "segcolr_output_", file_name, ".json")

if(!file.exists(json_path)){
  ground_results <- grounded_segmentation_cli(img_path,
    labels,
    output_json = "/home/jboyko/SegColR/extdata/json/",
    output_plot = "/home/jboyko/SegColR/extdata/plot/")
  json_path = ground_results$json_path
}

seg_results <- load_segmentation_results(
  image_path = img_path,
  json_path = json_path,
  mask_format = "image"
)

plot_seg_results(
  seg_results = seg_results,
  mask_colors = "Set1",
  background = "grayscale",
  show_label = TRUE,
  show_score = TRUE,
  show_bbox = TRUE,
  score_threshold = 0.5,
  label_size = 1.2,
  bbox_thickness = 2,
  mask_alpha = 0.3
)


## ---- fig.width=8, fig.height=5-----------------------------------------------
color_results <- process_masks_and_extract_colors(
  image = seg_results$image,
  masks = seg_results$mask,
  scores = seg_results$score,
  labels = seg_results$label,
  include_labels = labels[1],
  exclude_labels = labels[2],
  score_threshold = 0.3,
  n_colors = 5
)

plot_color_info(color_results)

## -----------------------------------------------------------------------------
img_path <- example_data$image_paths[8]
labels <- "a mammal."
file_name <- basename(img_path)
file_name <- sub("\\.[^.]*$", "", file_name)
directory <- dirname(img_path)
json_path <- paste0(gsub("images", "json/", directory), "segcolr_output_", file_name, ".json")

if(!file.exists(json_path)){
  ground_results <- grounded_segmentation_cli(img_path,
    labels,
    output_json = "/home/jboyko/SegColR/extdata/json/",
    output_plot = "/home/jboyko/SegColR/extdata/plot/")
  json_path = ground_results$json_path
}

seg_results <- load_segmentation_results(
  image_path = img_path,
  json_path = json_path,
  mask_format = "image"
)

plot_seg_results(
  seg_results = seg_results,
  mask_colors = "Set1",
  background = "grayscale",
  show_label = TRUE,
  show_score = TRUE,
  show_bbox = TRUE,
  score_threshold = 0.4,
  label_size = 1.2,
  bbox_thickness = 2,
  mask_alpha = 0.3
)


## ---- fig.width=8, fig.height=5-----------------------------------------------
color_results <- process_masks_and_extract_colors(
  image = seg_results$image,
  masks = seg_results$mask,
  scores = seg_results$score,
  labels = seg_results$label,
  include_labels = labels[1],
  exclude_labels = labels[2],
  score_threshold = 0.3,
  n_colors = 5
)

plot_color_info(color_results)

## -----------------------------------------------------------------------------
img_path <- example_data$image_paths[9]
labels <- c("doe. a deer. a female deer.")
file_name <- basename(img_path)
file_name <- sub("\\.[^.]*$", "", file_name)
directory <- dirname(img_path)
json_path <- paste0(gsub("images", "json/", directory), "segcolr_output_", file_name, ".json")

if(!file.exists(json_path)){
  ground_results <- grounded_segmentation_cli(img_path,
    labels,
    output_json = "/home/jboyko/SegColR/extdata/json/",
    output_plot = "/home/jboyko/SegColR/extdata/plot/")
  json_path = ground_results$json_path
}

seg_results <- load_segmentation_results(
  image_path = img_path,
  json_path = json_path,
  mask_format = "image"
)

plot_seg_results(
  seg_results = seg_results,
  mask_colors = "Set1",
  background = "grayscale",
  show_label = TRUE,
  show_score = TRUE,
  show_bbox = TRUE,
  score_threshold = 0.4,
  label_size = 1.2,
  bbox_thickness = 2,
  mask_alpha = 0.3
)


## ---- fig.width=8, fig.height=5-----------------------------------------------
color_results <- process_masks_and_extract_colors(
  image = seg_results$image,
  masks = seg_results$mask,
  scores = seg_results$score,
  labels = seg_results$label,
  include_labels = labels[1],
  exclude_labels = labels[2],
  score_threshold = 0.3,
  n_colors = 5
)

plot_color_info(color_results)

## -----------------------------------------------------------------------------
img_path <- example_data$image_paths[10]
labels <- c("a camera.")
file_name <- basename(img_path)
file_name <- sub("\\.[^.]*$", "", file_name)
directory <- dirname(img_path)
json_path <- paste0(gsub("images", "json/", directory), "segcolr_output_", file_name, ".json")

if(!file.exists(json_path)){
  ground_results <- grounded_segmentation_cli(img_path,
    labels,
    output_json = "/home/jboyko/SegColR/extdata/json/",
    output_plot = "/home/jboyko/SegColR/extdata/plot/")
  json_path = ground_results$json_path
}

seg_results <- load_segmentation_results(
  image_path = img_path,
  json_path = json_path,
  mask_format = "image"
)

plot_seg_results(
  seg_results = seg_results,
  mask_colors = "Set1",
  background = "grayscale",
  show_label = TRUE,
  show_score = TRUE,
  show_bbox = TRUE,
  score_threshold = 0.5,
  label_size = 1.2,
  bbox_thickness = 2,
  mask_alpha = 0.3
)


## ---- fig.width=8, fig.height=5-----------------------------------------------
color_results <- process_masks_and_extract_colors(
  image = seg_results$image,
  masks = seg_results$mask,
  scores = seg_results$score,
  labels = seg_results$label,
  include_labels = labels[1],
  exclude_labels = labels[2],
  score_threshold = 0.3,
  n_colors = 5
)

plot_color_info(color_results)

